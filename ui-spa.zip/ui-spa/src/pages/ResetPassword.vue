<template>
  <v-container>
    <div>
      <v-card class="elevation-12">
        <v-toolbar color="primary" dark flat>
          <v-toolbar-title>Reset Password</v-toolbar-title>
        </v-toolbar>
        <v-card-text>
          <v-form>
            <v-text-field
                v-model="email"
                label="Email"
                name="email"
                prepend-icon="mdi-email"
                type="text"
            />
            <v-text-field
                v-model="password"
                id="currentPassword"
                label="Current Password"
                name="currentPassword"
                prepend-icon="mdi-lock"
                type="password"
            />
            <v-text-field
                v-model="password"
                id="password"
                label="Password"
                name="password"
                prepend-icon="mdi-lock"
                type="password"
            />
            <v-text-field
                v-model="password"
                id="confPassword"
                label="Confirm Password"
                name="confPassword"
                prepend-icon="mdi-lock"
                type="password"
            />
          </v-form>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn v-on:click="resetPassword(this.$axios.query().select('id').where('email', ))" color="primary">Reset Password</v-btn>
        </v-card-actions>
      </v-card>
    </div>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      email: "",
      password: "",

      snackbar: {
        show: false,
        msge: "",
      },
    };
  },

  methods: {
    resetPassword(id) {
      this.$axios
          .post(`/accounts/${id}`, {
            password: this.password,
          })
          .then((result) => {
            this.showSnackbar(result.data.msge);
            if (result.data.ok) {
              this.$router.push({ name: "home-page" });
            }
          })
          .catch((err) => this.showSnackbar(err));
    },

    showSnackbar(msge) {
      this.snackbar.msge = msge;
      this.snackbar.show = true;
    },
  },
};
</script>