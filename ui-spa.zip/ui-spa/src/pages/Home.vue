<template>
  <v-container>
    <div>
      <h4 class="display-1">Welcome, Single-Page App User</h4>

      <p class="body-1">This is our award-winning home page.</p>
    </div>
  </v-container>
</template>
